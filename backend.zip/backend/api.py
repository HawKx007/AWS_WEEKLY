from flask import Flask, jsonify
from flask_cors import CORS

app = Flask(__name__)
CORS(app)  # Enable CORS for frontend-backend communication

# Mock product database
PRODUCTS = [
    {
        "id": 1,
        "name": "Organic Cotton T-shirt",
        "price": 25.00,
        "description": "100% organic cotton, sustainably sourced from certified farms. Soft, breathable, and perfect for everyday wear.",
        "image": "/static/images/tshirt.jpg",
        "category": "Tops",
        "eco_features": ["Organic", "Fair Trade", "Carbon Neutral"],
        "sizes": ["XS", "S", "M", "L", "XL"],
        "colors": ["White", "Black", "Forest Green"],
        "in_stock": True
    },
    {
        "id": 2,
        "name": "Recycled Denim Jeans",
        "price": 50.00,
        "description": "Made from 80% recycled denim fibers and 20% organic cotton. Classic fit with modern sustainability.",
        "image": "/static/images/jeans.jpg",
        "category": "Bottoms",
        "eco_features": ["Recycled Materials", "Water-Saving Process"],
        "sizes": ["28", "30", "32", "34", "36"],
        "colors": ["Blue", "Dark Blue", "Black"],
        "in_stock": True
    },
    {
        "id": 3,
        "name": "Hemp Hoodie",
        "price": 40.00,
        "description": "Cozy hoodie made from hemp and organic cotton blend. Naturally antimicrobial and ultra-durable.",
        "image": "/static/images/hoodie.jpg",
        "category": "Outerwear",
        "eco_features": ["Hemp Fiber", "Biodegradable", "Pesticide-Free"],
        "sizes": ["S", "M", "L", "XL"],
        "colors": ["Natural", "Charcoal", "Olive"],
        "in_stock": True
    },
    {
        "id": 4,
        "name": "Bamboo Dress",
        "price": 35.00,
        "description": "Elegant dress crafted from bamboo fiber. Naturally antibacterial, moisture-wicking, and incredibly soft.",
        "image": "/static/images/dress.jpg",
        "category": "Dresses",
        "eco_features": ["Bamboo Fiber", "Antibacterial", "Fast-Growing Resource"],
        "sizes": ["XS", "S", "M", "L"],
        "colors": ["Sage", "Dusty Rose", "Cream"],
        "in_stock": True
    },
    {
        "id": 5,
        "name": "Linen Blazer",
        "price": 65.00,
        "description": "Professional blazer made from European linen. Breathable, wrinkle-resistant, and timelessly stylish.",
        "image": "/static/images/blazer.jpg",
        "category": "Outerwear",
        "eco_features": ["Natural Fiber", "Biodegradable", "Low Impact"],
        "sizes": ["S", "M", "L", "XL"],
        "colors": ["Navy", "Beige", "White"],
        "in_stock": True
    },
    {
        "id": 6,
        "name": "Tencel Yoga Pants",
        "price": 45.00,
        "description": "Ultra-soft yoga pants made from Tencel fiber. Moisture-wicking, stretch-friendly, and eco-conscious.",
        "image": "/static/images/yoga_pants.jpg",
        "category": "Activewear",
        "eco_features": ["Tencel Fiber", "Closed-Loop Production", "Compostable"],
        "sizes": ["XS", "S", "M", "L", "XL"],
        "colors": ["Black", "Navy", "Forest Green"],
        "in_stock": True
    }
]

@app.route("/")
def home():
    return jsonify({
        "message": "StyleSphere API is running!",
        "version": "1.0",
        "endpoints": [
            "/products - Get all products",
            "/products/<id> - Get specific product",
            "/categories - Get product categories"
        ]
    })

@app.route("/products")
def get_products():
    """Get all products"""
    return jsonify(PRODUCTS)

@app.route("/products/<int:product_id>")
def get_product(product_id):
    """Get a specific product by ID"""
    product = next((p for p in PRODUCTS if p["id"] == product_id), None)
    if product:
        return jsonify(product)
    else:
        return jsonify({"error": "Product not found"}), 404

@app.route("/categories")
def get_categories():
    """Get all unique product categories"""
    categories = list(set(product["category"] for product in PRODUCTS))
    return jsonify(categories)

@app.route("/products/category/<category>")
def get_products_by_category(category):
    """Get products by category"""
    filtered_products = [p for p in PRODUCTS if p["category"].lower() == category.lower()]
    if filtered_products:
        return jsonify(filtered_products)
    else:
        return jsonify({"error": "No products found in this category"}), 404

@app.route("/search/<query>")
def search_products(query):
    """Search products by name or description"""
    results = []
    query_lower = query.lower()
    
    for product in PRODUCTS:
        if (query_lower in product["name"].lower() or 
            query_lower in product["description"].lower() or
            any(query_lower in feature.lower() for feature in product["eco_features"])):
            results.append(product)
    
    return jsonify(results)

@app.route("/health")
def health_check():
    """Health check endpoint for load balancer"""
    return jsonify({"status": "healthy", "service": "StyleSphere API"})

if __name__ == "__main__":
    print("Starting StyleSphere API server...")
    print("Available endpoints:")
    print("- GET /products - All products")
    print("- GET /products/<id> - Specific product")
    print("- GET /categories - Product categories")
    print("- GET /products/category/<category> - Products by category")
    print("- GET /search/<query> - Search products")
    print("- GET /health - Health check")
    
    app.run(host="0.0.0.0", port=6000, debug=True)