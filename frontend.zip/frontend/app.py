from flask import Flask, render_template, send_from_directory
import os

app = Flask(__name__)

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/products")
def products():
    return render_template("index.html")

@app.route("/about")
def about():
    return render_template("index.html")

# Serve static files (for product images)
@app.route('/static/images/<path:filename>')
def serve_images(filename):
    # Create images directory if it doesn't exist
    images_dir = os.path.join(app.static_folder, 'images')
    if not os.path.exists(images_dir):
        os.makedirs(images_dir)
    
    # Return placeholder if image doesn't exist
    image_path = os.path.join(images_dir, filename)
    if not os.path.exists(image_path):
        # Return a placeholder response
        return "Image not found", 404
    
    return send_from_directory(images_dir, filename)

if __name__ == "__main__":
    print("Starting StyleSphere Frontend server...")
    print("Frontend will be available at: http://localhost:5000")
    print("Make sure to start the backend server (api.py) on port 6000")
    
    app.run(host="0.0.0.0", port=5000, debug=True)
